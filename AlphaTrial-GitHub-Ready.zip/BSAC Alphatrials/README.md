# AlphaTrial: Quantitative Trading Strategy Platform
**QUANTACTIVE — CODE CONFLUX 2026**  
*Organized by Business Strategy and Analytics Club (BSAC), MNNIT Allahabad*  
**Problem Statement:** PS 01 — Build, Backtest & Validate a Trading Strategy  

### 🏆 Team MechMinds
- **Mahak Agrawal** (Team Leader — Architecture & Execution Engine)
- **Dipan Mandal** (Execution Friction & Trading Strategies)
- **Mayank Agarwal** (Quantitative Metrics & Overfit Validation)

---

## ⚡ 1. Setup & Dependencies

### Prerequisites
- **Python 3.10+** (Tested on Python 3.10, 3.11, 3.12)
- Git & Terminal / PowerShell

### Installation
Clone or navigate to the project directory and install all dependencies:

```bash
pip install -r requirements.txt
```

### Core Dependencies ([`requirements.txt`](requirements.txt))
| Package | Version | Purpose |
| :--- | :--- | :--- |
| `pandas` | `>=2.0.0` | Time-series data manipulation & signal generation |
| `numpy` | `>=1.24.0` | Vectorized returns, volatility & drawdown math |
| `scikit-learn` | `>=1.3.0` | Random Forest ML classifier for regime prediction |
| `scipy` | `>=1.11.0` | Statistical distributions & performance tests |
| `altair` | `>=5.0.0` | Interactive financial equity & underwater charts |
| `streamlit` | `>=1.30.0` | Institutional FinTech web dashboard |

---

## 🚀 2. Run Instructions

### 🌟 Option 1: Interactive Web Dashboard (Recommended)
Launches the full interactive UI with equity charts, regime breakdown, fee shock analysis, and tear sheet exports:
```bash
python -m streamlit run app.py
```
👉 Open browser at: **`http://localhost:8501`**

---

### 📋 Option 2: Step-by-Step Basic Functionalities Runner
Executes the exact 6 Basic Functionalities requested in the BSAC Problem Statement with clear terminal output:
```bash
python run_basic_functionalities.py
```
**What it runs:**
1. Loads CSV OHLCV data & validates clean schema
2. Computes Moving Average, RSI & Momentum signals
3. Simulates backtest with 10 bps fee + 5 bps slippage + cash limits
4. Computes performance metrics (CAGR, Sharpe, Sortino, Max Drawdown)
5. Benchmarks against passive Buy & Hold
6. Exports visual summary

---

### ⚡ Option 3: All-in-One Master Script
Runs the entire quantitative pipeline (Basic + Advanced + Brownie Points) in a single standalone script:
```bash
python alphatrial_simple.py
```

---

### 🧪 Option 4: Full Automated Test Suite
Runs all 4 strategies, verifies zero look-ahead bias, checks cash boundaries, and tests fee sensitivity:
```bash
python test_alpha.py
```


## 📂 3. Project Structure

```text
BSAC Alphatrials/
├── app.py                         # Interactive Streamlit Web Dashboard
├── run_basic_functionalities.py   # Step-by-step BSAC Problem Statement runner
├── alphatrial_simple.py           # Single-file clean master pipeline
├── test_alpha.py                  # Automated test & verification suite
├── requirements.txt               # Project dependencies
├── MechMinds_AlphaTrial_Presentation.pptx # 12-slide editable presentation
│
├── core/                          # Quantitative Core Engine
│   ├── simulator.py               # T+1 Open order fill engine (fees + slippage)
│   ├── metrics.py                 # CAGR, Sharpe, Sortino, Max Drawdown, Calmar
│   ├── validator.py               # Train/Test split, Sharpe degradation, Fee shock
│   └── optimizer.py               # In-Sample parameter grid search
│
├── strategies/                    # Modular Trading Strategies
│   ├── base_strategy.py           # Standard abstract interface
│   ├── moving_average.py          # Fast/Slow SMA crossover
│   ├── rsi_strategy.py            # Mean-reverting RSI (14-period)
│   ├── momentum_strategy.py       # Rate of Change (ROC 20-day)
│   └── ml_strategy.py             # Random Forest directional classifier
│
├── data/                          # Data Loader & Sample Datasets
│   ├── data_loader.py             # CSV reader & 4-regime synthetic generator
│   └── sample_data/               # RELIANCE, NIFTY50, AAPL CSVs
│
└── ui/                            # Dashboard Visuals
    ├── charts.py                  # Altair equity & drawdown visualizations
    └── report_exporter.py         # Markdown executive tear sheet exporter
```

---

## 🏛️ 4. Institutional Highlights 

- **Zero Look-Ahead Bias:** Signals generated on Bar $T$ Close execute strictly on **Bar $T+1$ Open** (`signal.shift(1)`).
- **Realistic Friction:** 10 bps brokerage fee + 5 bps adverse slippage modeled on every trade.
- **Capital Preservation:** In a -46.50% market crash, AlphaTrial limited drawdown to **24.72%** (preserving +21.78% capital).
- **Overfit Defense:** Walk-forward rolling validation & Sharpe Degradation Index alert if test decay exceeds 50%.
- **Fee Shock Analysis:** Proves that raising friction from 0 to 50 bps turns paper profits into losses, validating cost discipline.

---

## 📋 5. Feature Implementation Status

All features below are mapped directly to project source files to ensure submitted code strictly matches the live demo:

| Category | Feature / Requirement | Status | Module / Verification File |
| :--- | :--- | :---: | :--- |
| **Basic** | Historical OHLCV CSV Ingestion & Preprocessing | **Implemented** | [`data/data_loader.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/data/data_loader.py) |
| **Basic** | Technical Strategies (SMA Crossover, RSI, Momentum) | **Implemented** | [`strategies/`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/) |
| **Basic** | Rule-Based Signal Generation (1 = Long, 0 = Flat) | **Implemented** | [`strategies/`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/) |
| **Basic** | Execution Simulation with 10 bps Fee + 5 bps Slippage | **Implemented** | [`core/simulator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/simulator.py) |
| **Basic** | Cash Boundary Enforcement (Zero Borrowing / No Margin) | **Implemented** | [`core/simulator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/simulator.py) |
| **Basic** | Performance Metrics: Total Return, CAGR, Sharpe, Sortino, MDD | **Implemented** | [`core/metrics.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/metrics.py) |
| **Basic** | Passive Buy-and-Hold Benchmark Comparison Chart | **Implemented** | [`ui/charts.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/ui/charts.py) |
| **Advanced** | Chronological 70% In-Sample / 30% Out-of-Sample Split | **Implemented** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Advanced** | Walk-Forward Rolling-Window Validation (10 Cycles) | **Implemented** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Advanced** | Parameter Grid Search & In-Sample Optimization | **Implemented** | [`core/optimizer.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/optimizer.py) |
| **Advanced** | Market Regime Decomposition (Bull, Bear Crash, Chop) | **Implemented** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Advanced** | Scikit-Learn Random Forest Directional Classifier | **Implemented** | [`strategies/ml_strategy.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/ml_strategy.py) |
| **Brownie** | Friction Sensitivity Shock Analysis (0 to 50 bps curve) | **Implemented** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Brownie** | Overfitting Warning Alert (Sharpe Degradation > 50%) | **Implemented** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Brownie** | Provable Zero Look-Ahead Bias ($T+1$ Open Fill Enforcement) | **Implemented** | [`core/simulator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/simulator.py) |
| **Portfolio** | Multi-Asset Portfolio Balancing & Equal-Weight Aggregation | **Partial** | Supported on individual tickers; portfolio weighting architecture mapped in [`core/`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/) |
| **Roadmap** | Live Broker API Execution Gateway (Zerodha Kite / IBKR) | **Planned** | REST/WebSocket execution adapters designed for paper/live trading |
| **Roadmap** | Level-2 Tick-Level Limit Order Book (LOB) Queue Simulation | **Planned** | Sub-second microstructure queue-position modeling |

---

## 📚 6. Credits, Datasets & References

### External Libraries & Frameworks
- **[Pandas](https://pandas.pydata.org/)**: High-performance time-series indexing, rolling indicators, and vector arithmetic.
- **[NumPy](https://numpy.org/)**: Numerical linear algebra, array math, and drawdown peak calculation.
- **[Scikit-Learn](https://scikit-learn.org/)**: Random Forest ensemble classifier, lagged technical feature matrix engineering, and model persistence.
- **[Altair](https://altair-viz.github.io/) / [Vega-Lite](https://vega.github.io/vega-lite/)**: Declarative, responsive interactive financial equity curves and drawdown area charts.
- **[Streamlit](https://streamlit.io/)**: Real-time interactive FinTech analytics web interface and dashboard widgets.
- **[SciPy](https://scipy.org/)**: Statistical distribution functions and volatility modeling.

### Datasets Used
- **NIFTY 50 Benchmark Index**: Daily OHLCV time series (1,100 trading days) covering Bull, Bear Crash, and Sideways Chop regimes.
- **Reliance Industries Ltd (`RELIANCE_EQ.csv`)**: NSE blue-chip equity daily price action.
- **Apple Inc. (`AAPL_TECH.csv`)**: NASDAQ global benchmark daily price action.
- **Synthetic 4-Regime Price Generator**: Seeded, reproducible geometric Brownian motion with regime-dependent drift and volatility shifts ([`data/data_loader.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/data/data_loader.py)).




---
*Team MechMinds • BSAC QuantActive Code Conflux 2026 • MNNIT Allahabad*
