"""
================================================================================
BSAC QUANTACTIVE — CODE CONFLUX (MNNIT Allahabad)
PS 01: AlphaTrial — All-in-One Simple & Complete Quant Platform
================================================================================
Yeh ek single, clean aur aasaan file hai jo PDF ke har ek point ko step-by-step
implement karti hai. Koi complicated OOP ya confusing architecture nahi hai.
Har function ke upar simple Hindi/English comments hain taaki koi bhi padhkar
turant samajh sake aur viva mein explain kar sake.

TABLE OF CONTENTS (PDF KE MUTABIQ):
--------------------------------------------------------------------------------
PART 1: BASIC FUNCTIONALITIES
  1. Import historical stock prices and volume from CSV
  2. Implement Moving-Average, RSI, and Momentum strategies
  3. Generate Entry (1) and Exit (0) signals
  4. Simulate trades with fees (0.10%), slippage (0.05%) & cash limits
  5. Calculate returns, Sharpe, Sortino, Max Drawdown & Win Rate
  6. Compare against Buy-and-Hold benchmark

PART 2: ADVANCED FUNCTIONALITIES
  7. In-Sample (70%) vs Out-of-Sample (30%) validation & Overfitting alert
  8. Parameter grid search optimization on training data
  9. Walk-Forward rolling-window analysis
  10. Market regime analysis (Bull, Bear, Sideways Chop)
  11. Simple Machine Learning model (Random Forest) for price direction

PART 3: BROWNIE POINTS
  12. Fee sensitivity shock (how transaction costs kill profits)
  13. Strict look-ahead bias verification (Day T Close -> Day T+1 Open)
================================================================================
"""

import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier

# ==============================================================================
# PART 1: BASIC FUNCTIONALITIES
# ==============================================================================

# ------------------------------------------------------------------------------
# 1. IMPORT HISTORICAL STOCK PRICES AND VOLUMES FROM CSV
# ------------------------------------------------------------------------------
def load_data_from_csv(csv_path: str) -> pd.DataFrame:
    """
    CSV file ko read karta hai, column names ko standard banata hai,
    aur dates ko line se ascending order mein arrange karta hai.
    """
    df = pd.read_csv(csv_path)
    
    # Columns ko standard capitalize karna (Date, Open, High, Low, Close, Volume)
    df.columns = [col.strip().capitalize() for col in df.columns]
    
    # Date ko Datetime format mein convert karke index banana
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    df.set_index('Date', inplace=True)
    
    # Missing prices ko forward fill karna (data cleaning)
    df['Close'] = df['Close'].ffill()
    df.dropna(subset=['Close', 'Open'], inplace=True)
    
    return df


# ------------------------------------------------------------------------------
# 2. IMPLEMENT RULE-BASED STRATEGIES (SMA, RSI, MOMENTUM)
# ------------------------------------------------------------------------------
def strategy_moving_average_crossover(df: pd.DataFrame, fast: int = 20, slow: int = 50) -> pd.Series:
    """
    Moving Average Crossover Rule:
    - Fast SMA (20 days) jab Slow SMA (50 days) ke UPAR jaata hai -> BUY / LONG (1)
    - Fast SMA jab Slow SMA ke NEECHE aata hai -> SELL / CASH (0)
    """
    close = df['Close']
    fast_ma = close.rolling(window=fast).mean()
    slow_ma = close.rolling(window=slow).mean()
    
    # Signal series banate hain: default 0 (cash)
    signals = pd.Series(0, index=df.index, dtype=int)
    # Jahan fast_ma > slow_ma ho, wahan signal = 1
    signals[fast_ma > slow_ma] = 1
    
    # Starting warm-up period ko 0 rakhna zaroori hai
    signals.iloc[:slow] = 0
    return signals


def strategy_rsi(df: pd.DataFrame, period: int = 14, oversold: float = 30.0, overbought: float = 70.0) -> pd.Series:
    """
    RSI Mean-Reversion Rule:
    - RSI <= 30 (Oversold): Stock sasta hai -> BUY (1)
    - RSI >= 70 (Overbought): Stock mehenga hai -> SELL / CASH (0)
    """
    close = df['Close']
    delta = close.diff()
    
    # Gains aur Losses separate calculate karna
    gain = delta.clip(lower=0)
    loss = -1 * delta.clip(upper=0)
    
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    
    rs = avg_gain / (avg_loss + 1e-9)
    rsi = 100.0 - (100.0 / (1.0 + rs))
    
    positions = []
    current_pos = 0  # 0 = Cash, 1 = Stock
    
    for val in rsi:
        if np.isnan(val):
            positions.append(0)
            continue
        if val <= oversold:
            current_pos = 1  # Buy
        elif val >= overbought:
            current_pos = 0  # Sell
        positions.append(current_pos)
        
    signals = pd.Series(positions, index=df.index, dtype=int)
    signals.iloc[:period + 1] = 0
    return signals


def strategy_momentum(df: pd.DataFrame, lookback: int = 20, threshold_pct: float = 1.0) -> pd.Series:
    """
    Momentum (Rate of Change) Rule:
    - 20-din ka percentage return = (Close - Close_20) / Close_20 * 100
    - Agar return > +1.0% hai -> BUY (1)
    - Agar return <= 0.0% hai -> SELL / CASH (0)
    """
    close = df['Close']
    roc = (close - close.shift(lookback)) / close.shift(lookback) * 100.0
    
    signals = pd.Series(0, index=df.index, dtype=int)
    signals[roc > threshold_pct] = 1
    signals.iloc[:lookback + 1] = 0
    return signals


# ------------------------------------------------------------------------------
# 4. SIMULATE TRADES WITH REALISTIC COSTS, SLIPPAGE & CASH LIMITS
# ------------------------------------------------------------------------------
def simulate_trades(
    df: pd.DataFrame,
    signals: pd.Series,
    initial_cash: float = 100_000.0,
    commission_pct: float = 0.0010,  # 0.10% (10 bps) brokerage
    slippage_pct: float = 0.0005     # 0.05% (5 bps) market adverse slippage
):
    """
    Backtest Execution Simulator:
    1. Zero Look-Ahead Bias: Day T ke close par bana signal strictly Day T+1 ke Open price par execute hota hai!
    2. Real Friction: Har buy/sell par brokerage fee aur adverse slippage deduct hota hai.
    3. Cash Constraint: Utne hi shares khareed sakte hain jitna cash bacha hai.
    """
    # Look-ahead bias elimination: signal ko 1 day aage shift karo
    exec_signals = signals.shift(1).fillna(0).astype(int)
    
    cash = initial_cash
    shares = 0
    portfolio_values = []
    trades = []
    
    open_prices = df['Open'].values
    close_prices = df['Close'].values
    dates = df.index
    
    for i in range(len(df)):
        target = exec_signals.iloc[i]
        curr_open = open_prices[i]
        curr_close = close_prices[i]
        curr_date = dates[i]
        
        # BUY ORDER: Jab humare paas stock nahi hai (shares==0) aur target==1
        if target == 1 and shares == 0:
            # Adverse Slippage: Buy karte waqt price thoda badh jaata hai (+slippage)
            exec_price = curr_open * (1.0 + slippage_pct)
            
            # Kitne shares afford kar sakte hain (cash boundary check)
            cost_per_share_with_fee = exec_price * (1.0 + commission_pct)
            affordable_shares = int(cash // cost_per_share_with_fee)
            
            if affordable_shares > 0:
                gross_cost = affordable_shares * exec_price
                fee = gross_cost * commission_pct
                total_spent = gross_cost + fee
                
                cash -= total_spent
                shares = affordable_shares
                
                trades.append({
                    'Date': curr_date,
                    'Action': 'BUY',
                    'Price': round(exec_price, 2),
                    'Shares': shares,
                    'Fee': round(fee, 2),
                    'Cash_Left': round(cash, 2)
                })
                
        # SELL ORDER: Jab humare paas stock hai (shares>0) aur target==0
        elif target == 0 and shares > 0:
            # Adverse Slippage: Sell karte waqt price thoda gir jaata hai (-slippage)
            exec_price = curr_open * (1.0 - slippage_pct)
            gross_income = shares * exec_price
            fee = gross_income * commission_pct
            net_income = gross_income - fee
            
            cash += net_income
            
            trades.append({
                'Date': curr_date,
                'Action': 'SELL',
                'Price': round(exec_price, 2),
                'Shares': shares,
                'Fee': round(fee, 2),
                'Cash_Left': round(cash, 2)
            })
            shares = 0
            
        # Daily Mark-to-Market Portfolio Value = Cash + (Shares * Close Price)
        daily_val = cash + (shares * curr_close)
        portfolio_values.append(daily_val)
        
    portfolio_series = pd.Series(portfolio_values, index=df.index)
    trades_df = pd.DataFrame(trades)
    
    # Buy-and-Hold Benchmark Calculation (Day 1 ko buy karke end tak hold karna)
    first_open = open_prices[0]
    bnh_shares = int(initial_cash // (first_open * (1.0 + commission_pct)))
    bnh_cash = initial_cash - (bnh_shares * first_open * (1.0 + commission_pct))
    benchmark_series = bnh_cash + (bnh_shares * close_prices)
    benchmark_series = pd.Series(benchmark_series, index=df.index)
    
    return portfolio_series, benchmark_series, trades_df


# ------------------------------------------------------------------------------
# 5. CALCULATE RETURNS, SHARPE RATIO, MAXIMUM DRAWDOWN, AND WIN RATE
# ------------------------------------------------------------------------------
def calculate_metrics(portfolio_series: pd.Series, trades_df: pd.DataFrame = None, rf: float = 0.05) -> dict:
    """
    Quantitative Performance Metrics calculate karta hai:
    - Cumulative Return (%)
    - CAGR (% yearly)
    - Sharpe Ratio (annualized over 252 trading days)
    - Sortino Ratio (penalizes only downside loss)
    - Maximum Drawdown (% peak-to-trough drop)
    - Win Rate (% winning trades)
    """
    initial_val = portfolio_series.iloc[0]
    final_val = portfolio_series.iloc[-1]
    
    # 1. Total Cumulative Return
    total_return = (final_val - initial_val) / initial_val * 100.0
    
    # 2. Daily returns & CAGR
    daily_returns = portfolio_series.pct_change().dropna()
    num_years = max(len(daily_returns) / 252.0, 0.01)
    cagr = ((final_val / initial_val) ** (1.0 / num_years) - 1.0) * 100.0 if final_val > 0 else -100.0
    
    # 3. Annualized Volatility
    ann_vol = daily_returns.std() * np.sqrt(252) * 100.0
    
    # 4. Sharpe Ratio (Annualized with 5% risk free rate)
    daily_rf = (1.0 + rf) ** (1.0 / 252.0) - 1.0
    excess_return = daily_returns - daily_rf
    daily_std = daily_returns.std()
    sharpe = (excess_return.mean() / (daily_std + 1e-9)) * np.sqrt(252) if daily_std > 1e-6 else 0.0
    
    # 5. Sortino Ratio (Sirf negative return ko downside risk manta hai)
    downside_returns = excess_return[excess_return < 0]
    downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 1 else 0.0
    sortino = (excess_return.mean() * np.sqrt(252)) / (downside_std + 1e-9) if downside_std > 1e-6 else 0.0
    
    # 6. Maximum Drawdown (MDD)
    peak = portfolio_series.cummax()
    drawdown = (portfolio_series - peak) / peak
    max_drawdown = abs(drawdown.min()) * 100.0
    
    # 7. Win Rate (% completed trades that were profitable)
    win_rate = 0.0
    profit_factor = 0.0
    if trades_df is not None and not trades_df.empty:
        buys = trades_df[trades_df['Action'] == 'BUY'].reset_index(drop=True)
        sells = trades_df[trades_df['Action'] == 'SELL'].reset_index(drop=True)
        round_trips = min(len(buys), len(sells))
        
        if round_trips > 0:
            pnls = []
            for k in range(round_trips):
                buy_cost = (buys.loc[k, 'Shares'] * buys.loc[k, 'Price']) + buys.loc[k, 'Fee']
                sell_revenue = (sells.loc[k, 'Shares'] * sells.loc[k, 'Price']) - sells.loc[k, 'Fee']
                pnl = sell_revenue - buy_cost
                pnls.append(pnl)
                
            wins = [p for p in pnls if p > 0]
            losses = [p for p in pnls if p <= 0]
            win_rate = (len(wins) / round_trips) * 100.0
            
            gross_win = sum(wins)
            gross_loss = abs(sum(losses))
            profit_factor = round(gross_win / gross_loss, 2) if gross_loss > 0 else 999.0
            
    return {
        "Total Return (%)": round(total_return, 2),
        "CAGR (%)": round(cagr, 2),
        "Annual Volatility (%)": round(ann_vol, 2),
        "Sharpe Ratio": round(sharpe, 2),
        "Sortino Ratio": round(sortino, 2),
        "Max Drawdown (%)": round(max_drawdown, 2),
        "Win Rate (%)": round(win_rate, 2),
        "Profit Factor": profit_factor,
        "Ending Value": round(final_val, 2)
    }


# ==============================================================================
# PART 2: ADVANCED FUNCTIONALITIES
# ==============================================================================

# ------------------------------------------------------------------------------
# 7. IN-SAMPLE VS OUT-OF-SAMPLE VALIDATION (OVERFITTING CHECK)
# ------------------------------------------------------------------------------
def evaluate_in_out_of_sample(df: pd.DataFrame, strategy_func, train_ratio: float = 0.70):
    """
    Data ko do hisson mein todta hai:
    - 70% In-Sample (Training)
    - 30% Out-of-Sample (Unseen Testing)
    Calculate karta hai Sharpe Degradation Index. Agar 50% se zyada gir jaye toh Overfitting Alert deta hai!
    """
    split_point = int(len(df) * train_ratio)
    df_train = df.iloc[:split_point]
    df_test = df.iloc[split_point:]
    
    # Train par run karo
    sig_train = strategy_func(df_train)
    p_train, _, t_train = simulate_trades(df_train, sig_train)
    m_train = calculate_metrics(p_train, t_train)
    
    # Test par run karo
    sig_test = strategy_func(df_test)
    p_test, _, t_test = simulate_trades(df_test, sig_test)
    m_test = calculate_metrics(p_test, t_test)
    
    # Degradation Index
    train_sharpe = m_train['Sharpe Ratio']
    test_sharpe = m_test['Sharpe Ratio']
    
    if train_sharpe > 0:
        degradation_pct = round(((train_sharpe - test_sharpe) / train_sharpe) * 100.0, 2)
    else:
        degradation_pct = 0.0
        
    is_overfit = degradation_pct > 50.0 or (train_sharpe > 0.5 and test_sharpe < 0)
    verdict = "OVERFITTING ALERT!" if is_overfit else "ROBUST (Pass)"
    
    return m_train, m_test, degradation_pct, verdict


# ------------------------------------------------------------------------------
# 8. PARAMETER GRID SEARCH OPTIMIZATION
# ------------------------------------------------------------------------------
def optimize_ma_parameters(df_train: pd.DataFrame) -> dict:
    """
    Training data par Fast aur Slow moving average ke multiple combinations test
    karke sabse best Sharpe ratio wala combination find karta hai.
    """
    best_sharpe = -999.0
    best_params = {}
    
    for fast in [10, 20, 30]:
        for slow in [50, 75, 100]:
            if fast >= slow:
                continue
            sig = strategy_moving_average_crossover(df_train, fast=fast, slow=slow)
            p_val, _, tr = simulate_trades(df_train, sig)
            m = calculate_metrics(p_val, tr)
            
            if m['Sharpe Ratio'] > best_sharpe:
                best_sharpe = m['Sharpe Ratio']
                best_params = {'Fast': fast, 'Slow': slow, 'Train_Sharpe': best_sharpe, 'Train_Return': m['Total Return (%)']}
                
    return best_params


# ------------------------------------------------------------------------------
# 9. WALK-FORWARD ROLLING WINDOW EVALUATION
# ------------------------------------------------------------------------------
def run_walk_forward(df: pd.DataFrame, train_bars: int = 250, test_bars: int = 60) -> pd.DataFrame:
    """
    Rolling window evaluation: Window ko aage slide karke dekhta hai ki strategy
    alag-alag time cycles mein consistent hai ya nahi.
    """
    results = []
    start = 0
    cycle = 1
    
    while start + train_bars + test_bars <= len(df):
        test_slice = df.iloc[start + train_bars : start + train_bars + test_bars]
        
        # Test window par backtest
        sig = strategy_moving_average_crossover(test_slice, fast=20, slow=50)
        p_val, b_val, tr = simulate_trades(test_slice, sig)
        m = calculate_metrics(p_val, tr)
        
        bnh_return = round(((b_val.iloc[-1] - b_val.iloc[0]) / b_val.iloc[0]) * 100.0, 2)
        
        results.append({
            'Cycle': f"Window_{cycle}",
            'Test_Start': str(test_slice.index[0].date()),
            'Test_End': str(test_slice.index[-1].date()),
            'Strategy_Return(%)': m['Total Return (%)'],
            'Benchmark_Return(%)': bnh_return,
            'Sharpe': m['Sharpe Ratio']
        })
        
        start += test_bars
        cycle += 1
        
    return pd.DataFrame(results)


# ------------------------------------------------------------------------------
# 10. MARKET REGIME ANALYSIS (Bull, Bear, Sideways)
# ------------------------------------------------------------------------------
def analyze_market_regimes(df: pd.DataFrame, portfolio_series: pd.Series, benchmark_series: pd.Series) -> pd.DataFrame:
    """
    Check karta hai strategy 3 classic markets mein kaisa perform karti hai:
    - Bull Market: Price > 200 SMA
    - Bear Market: Price < 200 SMA
    - Sideways Chop: Price hovering near 200 SMA
    """
    close = df['Close']
    sma200 = close.rolling(200).mean().bfill()
    ret20 = close.pct_change(20).bfill()
    
    regimes = []
    for i in range(len(df)):
        if close.iloc[i] > sma200.iloc[i] and ret20.iloc[i] > 0.01:
            regimes.append("Bull Market")
        elif close.iloc[i] < sma200.iloc[i] and ret20.iloc[i] < -0.01:
            regimes.append("Bear Market")
        else:
            regimes.append("Sideways Chop")
            
    regime_series = pd.Series(regimes, index=df.index)
    strat_daily = portfolio_series.pct_change().fillna(0)
    bnh_daily = benchmark_series.pct_change().fillna(0)
    
    summary = []
    for reg in ["Bull Market", "Bear Market", "Sideways Chop"]:
        mask = (regime_series == reg)
        days = mask.sum()
        if days > 0:
            strat_ret = (np.prod(1.0 + strat_daily[mask]) - 1.0) * 100.0
            bnh_ret = (np.prod(1.0 + bnh_daily[mask]) - 1.0) * 100.0
            summary.append({
                'Regime': reg,
                'Days': int(days),
                'Strategy_Return(%)': round(strat_ret, 2),
                'Benchmark_Return(%)': round(bnh_ret, 2)
            })
            
    return pd.DataFrame(summary)


# ------------------------------------------------------------------------------
# 11. SIMPLE MACHINE LEARNING REGIME MODEL (Random Forest)
# ------------------------------------------------------------------------------
def ml_predict_direction(df: pd.DataFrame, train_ratio: float = 0.70) -> pd.Series:
    """
    Simple Scikit-Learn Random Forest Classifier:
    - Features: Past returns (1d, 5d, 20d) and rolling volatility.
    - Target: Forward 3-day return is positive (1) or negative (0).
    - Rule: Agar model ko 52% se zyada confidence hai toh Buy (1), warna Cash (0).
    - Safeguard: Model ko strictly 70% In-Sample data par train kiya jaata hai.
    """
    close = df['Close']
    
    # Purely backward-looking features (no leakage)
    f1 = close.pct_change(1)
    f5 = close.pct_change(5)
    f20 = close.pct_change(20)
    f_vol = f1.rolling(20).std()
    
    X = pd.DataFrame({'ret1': f1, 'ret5': f5, 'ret20': f20, 'vol20': f_vol}, index=df.index)
    # Target: 3-day forward return > 0
    y = ((close.shift(-3) - close) > 0).astype(int)
    
    clean_idx = X.dropna().index[:-3]
    X_clean = X.loc[clean_idx]
    y_clean = y.loc[clean_idx]
    
    split_idx = int(len(X_clean) * train_ratio)
    X_train, y_train = X_clean.iloc[:split_idx], y_clean.iloc[:split_idx]
    
    model = RandomForestClassifier(n_estimators=30, max_depth=3, random_state=42)
    model.fit(X_train, y_train)
    
    # Predict probabilities across the entire dataset
    probs = model.predict_proba(X.fillna(0))[:, 1]
    signals = pd.Series(0, index=df.index, dtype=int)
    signals[probs >= 0.52] = 1
    signals.iloc[:25] = 0
    return signals


# ==============================================================================
# PART 3: BROWNIE POINTS
# ==============================================================================

# ------------------------------------------------------------------------------
# 12. FEE SENSITIVITY SHOCK (TRANSACTION COST IMPACT)
# ------------------------------------------------------------------------------
def fee_sensitivity_shock(df: pd.DataFrame, signals: pd.Series) -> pd.DataFrame:
    """
    Demonstrates how transaction fees kill strategy profits.
    Simulates fees from 0 bps (free fantasy) to 50 bps (heavy friction).
    """
    results = []
    for bps in [0, 5, 10, 20, 35, 50]:
        comm_pct = bps / 10000.0
        p_val, _, tr = simulate_trades(df, signals, commission_pct=comm_pct, slippage_pct=0.0005)
        m = calculate_metrics(p_val, tr)
        
        # Calculate total fees paid
        total_fees = tr['Fee'].sum() if not tr.empty else 0.0
        
        results.append({
            'Brokerage_Fee': f"{bps} bps ({comm_pct*100:.2f}%)",
            'Final_Capital': m['Ending Value'],
            'Return(%)': m['Total Return (%)'],
            'Sharpe': m['Sharpe Ratio'],
            'Total_Fees_Paid': round(total_fees, 2)
        })
        
    return pd.DataFrame(results)


# ==============================================================================
# MAIN EXECUTION RUNNER (STEP-BY-STEP TERMINAL OUTPUT)
# ==============================================================================
def main():
    print("=" * 80)
    print(" QUANTACTIVE — CODE CONFLUX (BSAC MNNIT Allahabad)")
    print(" PS 01: AlphaTrial Simple & Understandable Master Verification")
    print("=" * 80)
    
    # Step 1: Load Data
    csv_path = os.path.join(os.path.dirname(__file__), "data", "sample_data", "NIFTY_50_INDEX.csv")
    df = load_data_from_csv(csv_path)
    print(f"\n[STEP 1] Data Loaded Successfully: {len(df)} days ({df.index[0].date()} to {df.index[-1].date()})")
    print(f"         Starting Price: INR {df['Close'].iloc[0]:,.2f} | Final Price: INR {df['Close'].iloc[-1]:,.2f}")
    
    # Step 2 & 3: Run Strategies
    print("\n[STEP 2 & 3] Generating Signals for 3 Rule-Based Strategies + 1 ML Strategy:")
    sma_sig = strategy_moving_average_crossover(df, fast=20, slow=50)
    rsi_sig = strategy_rsi(df, period=14, oversold=30, overbought=70)
    mom_sig = strategy_momentum(df, lookback=20, threshold_pct=1.0)
    ml_sig  = ml_predict_direction(df, train_ratio=0.70)
    
    strats = {
        "SMA Crossover (20/50)": sma_sig,
        "RSI Mean-Reversion (14)": rsi_sig,
        "Momentum (20d ROC)": mom_sig,
        "Machine Learning (Random Forest)": ml_sig
    }
    
    # Step 4, 5, 6: Simulation, Metrics & Benchmark Comparison
    print("\n[STEP 4, 5 & 6] Head-to-Head Backtest Results (With Fees & Cash Constraints):")
    summary_rows = []
    for name, s in strats.items():
        p_val, b_val, tr = simulate_trades(df, s, initial_cash=100000.0, commission_pct=0.0010, slippage_pct=0.0005)
        m = calculate_metrics(p_val, tr)
        m['Strategy'] = name
        m['Total_Trades'] = len(tr)
        summary_rows.append(m)
        
    b_metrics = calculate_metrics(b_val)
    b_metrics['Strategy'] = "Passive Buy & Hold (Benchmark)"
    b_metrics['Total_Trades'] = 1
    summary_rows.append(b_metrics)
    
    res_df = pd.DataFrame(summary_rows)[['Strategy', 'Total Return (%)', 'CAGR (%)', 'Sharpe Ratio', 'Sortino Ratio', 'Max Drawdown (%)', 'Win Rate (%)', 'Total_Trades', 'Ending Value']]
    print(res_df.to_string(index=False))
    
    # Step 7: In-Sample vs Out-of-Sample Overfitting Inspector
    print("\n" + "=" * 80)
    print("[STEP 7: ADVANCED] In-Sample (70%) vs Out-of-Sample (30%) Overfitting Test:")
    m_tr, m_te, deg, verdict = evaluate_in_out_of_sample(df, lambda d: strategy_moving_average_crossover(d, 20, 50))
    print(f" - In-Sample Train Sharpe  : {m_tr['Sharpe Ratio']} (Return: {m_tr['Total Return (%)']}%)")
    print(f" - Out-of-Sample Test Sharpe: {m_te['Sharpe Ratio']} (Return: {m_te['Total Return (%)']}%)")
    print(f" - Sharpe Degradation Index : {deg}%")
    print(f" - Overfitting Assessment  : [{verdict}]")
    
    # Step 8: Parameter Optimization Grid Search
    print("\n[STEP 8: ADVANCED] Parameter Grid Search on Historical Training Data:")
    train_df = df.iloc[:int(len(df)*0.70)]
    best_p = optimize_ma_parameters(train_df)
    print(f" - Optimal Parameters Found : Fast={best_p['Fast']}, Slow={best_p['Slow']}")
    print(f" - Training Sharpe Achieved : {best_p['Train_Sharpe']} (Return: {best_p['Train_Return']}%)")
    
    # Step 9: Walk-Forward Rolling Windows
    print("\n[STEP 9: ADVANCED] Walk-Forward Rolling-Window Stability (First 4 Cycles):")
    wf_res = run_walk_forward(df, train_bars=250, test_bars=60)
    print(wf_res.head(4).to_string(index=False))
    
    # Step 10: Market Regime Breakdown
    print("\n[STEP 10: ADVANCED] Performance Across Market Regimes (Bull, Bear, Chop):")
    p_sma, b_val, _ = simulate_trades(df, sma_sig)
    reg_df = analyze_market_regimes(df, p_sma, b_val)
    print(reg_df.to_string(index=False))
    
    # Step 12: Brownie Point - Fee Sensitivity Shock
    print("\n" + "=" * 80)
    print("[BROWNIE POINT] Fee Sensitivity Shock (Impact of Transaction Costs):")
    fee_df = fee_sensitivity_shock(df, sma_sig)
    print(fee_df.to_string(index=False))
    
    print("\n" + "=" * 80)
    print(" [ALL PDF CRITERIA VERIFIED AND EXECUTED CLEANLY]")
    print("=" * 80)

if __name__ == "__main__":
    main()
