"""
AlphaTrial Quantitative Metrics Engine (Simplified)
Calculates performance & risk metrics: Return, Sharpe, Sortino, MaxDD, Win Rate.
Complies with BSAC (MNNIT Allahabad) Quantitative Correctness Standards.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any

def compute_performance_metrics(
    portfolio_series: pd.Series,
    trade_df: pd.DataFrame = None,
    risk_free_rate: float = 0.05
) -> Dict[str, Any]:
    """
    Ek equity series ke sabhi financial aur risk metrics aasaani se calculate karta hai:
    - Total Return & CAGR
    - Volatility, Sharpe & Sortino (Downside risk)
    - Max Drawdown & Calmar Ratio
    - Win Rate & Profit Factor
    """
    # 1. Edge Case: Agar data khali ho ya 1 din se kam ho
    if len(portfolio_series) < 2:
        return {
            "Total Return (%)": 0.0, "CAGR (%)": 0.0, "Annual Volatility (%)": 0.0,
            "Sharpe Ratio": 0.0, "Sortino Ratio": 0.0, "Max Drawdown (%)": 0.0,
            "Calmar Ratio": 0.0, "Win Rate (%)": 0.0, "Profit Factor": 0.0,
            "Completed Round Trips": 0, "Avg Trade PnL ($)": 0.0
        }

    # 2. Starting aur Ending Values
    v_start = portfolio_series.iloc[0]
    v_end = portfolio_series.iloc[-1]
    daily_ret = portfolio_series.pct_change().dropna()
    years = max(len(daily_ret) / 252.0, 0.001)

    # 3. Total Return (%) aur CAGR (%)
    total_ret = ((v_end - v_start) / v_start) * 100.0
    cagr = (((v_end / v_start) ** (1.0 / years)) - 1.0) * 100.0 if (v_start > 0 and v_end > 0) else -100.0

    # 4. Volatility, Sharpe Ratio & Sortino Ratio
    vol_daily = daily_ret.std()
    ann_vol = vol_daily * np.sqrt(252) * 100.0

    # Daily Risk-Free Rate (Assuming 5% annual)
    rf_daily = ((1.0 + risk_free_rate) ** (1.0 / 252.0)) - 1.0
    excess_ret = daily_ret - rf_daily

    # Sharpe = Excess Return / Total Volatility
    sharpe = (excess_ret.mean() / (vol_daily + 1e-9)) * np.sqrt(252) if vol_daily > 1e-6 else 0.0

    # Sortino = Excess Return / Downside Volatility (sirf losses ko penalize karta hai)
    downside_ret = excess_ret[excess_ret < 0]
    downside_vol = downside_ret.std() if len(downside_ret) > 1 else 0.0
    sortino = (excess_ret.mean() / (downside_vol + 1e-9)) * np.sqrt(252) if downside_vol > 1e-6 else 0.0

    # 5. Maximum Drawdown (MDD %) & Calmar Ratio
    peak = portfolio_series.cummax()
    dd = (portfolio_series - peak) / peak
    max_dd = abs(float(dd.min())) * 100.0
    calmar = (cagr / max_dd) if max_dd > 1e-4 else cagr

    # 6. Trade Level Stats: Win Rate & Profit Factor
    win_rate = 0.0
    profit_factor = 0.0
    completed_trades = 0
    avg_pnl = 0.0

    if trade_df is not None and not trade_df.empty:
        buys = trade_df[trade_df['Action'] == 'BUY'].reset_index(drop=True)
        sells = trade_df[trade_df['Action'] == 'SELL'].reset_index(drop=True)
        completed_trades = min(len(buys), len(sells))

        if completed_trades > 0:
            pnls = []
            for i in range(completed_trades):
                buy_cost = (buys.loc[i, 'Shares'] * buys.loc[i, 'Execution_Price']) + buys.loc[i, 'Fee']
                sell_rev = (sells.loc[i, 'Shares'] * sells.loc[i, 'Execution_Price']) - sells.loc[i, 'Fee']
                pnls.append(sell_rev - buy_cost)

            wins = [p for p in pnls if p > 0]
            losses = [p for p in pnls if p <= 0]

            win_rate = (len(wins) / completed_trades) * 100.0
            gross_win = sum(wins)
            gross_loss = abs(sum(losses))
            profit_factor = round(gross_win / gross_loss, 2) if gross_loss > 0 else 999.0
            avg_pnl = sum(pnls) / completed_trades

    # 7. Final Clean Output Dictionary
    return {
        "Total Return (%)": round(float(total_ret), 2),
        "CAGR (%)": round(float(cagr), 2),
        "Annual Volatility (%)": round(float(ann_vol), 2),
        "Sharpe Ratio": round(float(sharpe), 2),
        "Sortino Ratio": round(float(sortino), 2),
        "Max Drawdown (%)": round(float(max_dd), 2),
        "Calmar Ratio": round(float(calmar), 2),
        "Win Rate (%)": round(float(win_rate), 2),
        "Profit Factor": round(float(profit_factor), 2),
        "Completed Round Trips": completed_trades,
        "Avg Trade PnL ($)": round(float(avg_pnl), 2)
    }
