"""
AlphaTrial Parameter Optimizer (Simplified)
Grid-search parameter optimization on historical In-Sample training data.
"""

import pandas as pd
from typing import Dict, Any, List
from strategies.moving_average import MovingAverageCrossover
from strategies.rsi_strategy import RSIStrategy
from strategies.momentum_strategy import MomentumStrategy
from .simulator import BacktestSimulator
from .metrics import compute_performance_metrics

def optimize_parameters(
    strategy_type: str,
    df_train: pd.DataFrame,
    param_grid: Dict[str, List[Any]],
    objective_metric: str = "Sharpe Ratio",
    initial_capital: float = 100_000.0,
    commission_pct: float = 0.0010,
    slippage_pct: float = 0.0005
) -> Dict[str, Any]:
    """Training data par parameter combinations test karke best row return karta hai."""
    sim = BacktestSimulator(initial_capital, commission_pct, slippage_pct)
    records = []
    
    # 1. Moving Average Crossover Grid
    if strategy_type == "MovingAverageCrossover":
        fast_list = param_grid.get("fast_window", [10, 20, 30])
        slow_list = param_grid.get("slow_window", [50, 100])
        ma_types = param_grid.get("ma_type", ["SMA"])
        
        for ma in ma_types:
            for f in fast_list:
                for s in slow_list:
                    if f >= s: continue
                    strat = MovingAverageCrossover(f, s, ma)
                    eq, trades, _ = sim.run_backtest(df_train, strat.generate_signals(df_train))
                    m = compute_performance_metrics(eq['Portfolio_Value'], trades)
                    records.append({
                        "fast_window": f, "slow_window": s, "ma_type": ma,
                        "Sharpe Ratio": m["Sharpe Ratio"], "Total Return (%)": m["Total Return (%)"],
                        "Max Drawdown (%)": m["Max Drawdown (%)"], "Calmar Ratio": m["Calmar Ratio"]
                    })
                    
    # 2. RSI Strategy Grid
    elif strategy_type == "RSIStrategy":
        for p in param_grid.get("period", [10, 14, 21]):
            for os_val in param_grid.get("oversold", [25, 30]):
                for ob_val in param_grid.get("overbought", [70, 75]):
                    strat = RSIStrategy(p, os_val, ob_val)
                    eq, trades, _ = sim.run_backtest(df_train, strat.generate_signals(df_train))
                    m = compute_performance_metrics(eq['Portfolio_Value'], trades)
                    records.append({
                        "period": p, "oversold": os_val, "overbought": ob_val,
                        "Sharpe Ratio": m["Sharpe Ratio"], "Total Return (%)": m["Total Return (%)"],
                        "Max Drawdown (%)": m["Max Drawdown (%)"], "Calmar Ratio": m["Calmar Ratio"]
                    })
                    
    # 3. Momentum Strategy Grid
    elif strategy_type == "MomentumStrategy":
        for lb in param_grid.get("lookback", [10, 20, 40]):
            for thr in param_grid.get("entry_threshold", [0.5, 1.0, 2.0]):
                strat = MomentumStrategy(lb, thr)
                eq, trades, _ = sim.run_backtest(df_train, strat.generate_signals(df_train))
                m = compute_performance_metrics(eq['Portfolio_Value'], trades)
                records.append({
                    "lookback": lb, "entry_threshold": thr,
                    "Sharpe Ratio": m["Sharpe Ratio"], "Total Return (%)": m["Total Return (%)"],
                    "Max Drawdown (%)": m["Max Drawdown (%)"], "Calmar Ratio": m["Calmar Ratio"]
                })
                
    if not records:
        return {"best_row": {}, "results_table": pd.DataFrame()}
        
    res_df = pd.DataFrame(records).sort_values(by=objective_metric, ascending=False).reset_index(drop=True)
    return {"best_row": res_df.iloc[0].to_dict(), "results_table": res_df}
