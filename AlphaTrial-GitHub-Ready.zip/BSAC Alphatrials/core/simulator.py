"""
AlphaTrial Backtest Simulator (Simplified)
Simulates trade execution with:
- Zero Look-Ahead Bias: Day T Close signals execute at Day T+1 Open.
- Real Friction: Brokerage fees (10 bps) + Adverse slippage (5 bps).
- Cash Boundary: Share quantity constrained by available cash.
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any

class BacktestSimulator:
    def __init__(self, initial_capital: float = 100_000.0, commission_pct: float = 0.0010, slippage_pct: float = 0.0005):
        self.initial_capital = float(initial_capital)
        self.commission_pct = float(commission_pct)
        self.slippage_pct = float(slippage_pct)

    def run_backtest(self, df: pd.DataFrame, signals: pd.Series) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
        # Index align karna
        idx = df.index.intersection(signals.index)
        data = df.loc[idx]
        
        # Look-Ahead Bias Elimination: Day T ke signal ko shift karke Day T+1 Open par execute karna
        exec_signals = signals.loc[idx].shift(1).fillna(0).astype(int)
        
        cash = self.initial_capital
        shares = 0
        portfolio_values = []
        trades = []
        trade_id = 1
        
        tot_fee = 0.0
        tot_slip = 0.0
        
        opens = data['Open'].values
        closes = data['Close'].values
        dates = data.index
        
        for i in range(len(data)):
            target = exec_signals.iloc[i]
            open_p = opens[i]
            close_p = closes[i]
            d = dates[i]
            
            # BUY ORDER (Cash -> Stock)
            if target == 1 and shares == 0:
                exec_price = open_p * (1.0 + self.slippage_pct)
                slip_cost = open_p * self.slippage_pct
                
                # Maximum affordable shares
                cost_per_share = exec_price * (1.0 + self.commission_pct)
                num_shares = int(cash // cost_per_share)
                
                if num_shares > 0:
                    gross = num_shares * exec_price
                    fee = gross * self.commission_pct
                    cash -= (gross + fee)
                    shares = num_shares
                    
                    slip_total = num_shares * slip_cost
                    tot_fee += fee
                    tot_slip += slip_total
                    
                    trades.append({
                        'Trade_ID': trade_id, 'Date': d, 'Action': 'BUY',
                        'Open_Price': round(open_p, 2), 'Execution_Price': round(exec_price, 2),
                        'Shares': shares, 'Gross_Value': round(gross, 2), 'Fee': round(fee, 2),
                        'Slippage_Cost': round(slip_total, 2), 'Cash_Remaining': round(cash, 2)
                    })
                    trade_id += 1
                    
            # SELL ORDER (Stock -> Cash)
            elif target == 0 and shares > 0:
                exec_price = open_p * (1.0 - self.slippage_pct)
                slip_cost = open_p * self.slippage_pct
                
                gross = shares * exec_price
                fee = gross * self.commission_pct
                cash += (gross - fee)
                
                slip_total = shares * slip_cost
                tot_fee += fee
                tot_slip += slip_total
                
                trades.append({
                    'Trade_ID': trade_id, 'Date': d, 'Action': 'SELL',
                    'Open_Price': round(open_p, 2), 'Execution_Price': round(exec_price, 2),
                    'Shares': shares, 'Gross_Value': round(gross, 2), 'Fee': round(fee, 2),
                    'Slippage_Cost': round(slip_total, 2), 'Cash_Remaining': round(cash, 2)
                })
                trade_id += 1
                shares = 0
                
            portfolio_values.append(cash + (shares * close_p))
            
        equity_df = pd.DataFrame(index=data.index)
        equity_df['Portfolio_Value'] = portfolio_values
        equity_df['Daily_Return'] = equity_df['Portfolio_Value'].pct_change().fillna(0.0)
        
        # High-watermark aur Drawdown
        peak = equity_df['Portfolio_Value'].cummax()
        equity_df['Drawdown'] = (equity_df['Portfolio_Value'] - peak) / peak
        
        # Benchmark (Buy and Hold)
        bnh_shares = int(self.initial_capital // (opens[0] * (1.0 + self.commission_pct)))
        bnh_cash = self.initial_capital - (bnh_shares * opens[0] * (1.0 + self.commission_pct))
        equity_df['Benchmark_Value'] = bnh_cash + (bnh_shares * closes)
        equity_df['Benchmark_Daily_Return'] = equity_df['Benchmark_Value'].pct_change().fillna(0.0)
        bnh_peak = equity_df['Benchmark_Value'].cummax()
        equity_df['Benchmark_Drawdown'] = (equity_df['Benchmark_Value'] - bnh_peak) / bnh_peak
        
        trade_df = pd.DataFrame(trades) if trades else pd.DataFrame(columns=[
            'Trade_ID', 'Date', 'Action', 'Open_Price', 'Execution_Price', 'Shares', 'Gross_Value', 'Fee', 'Slippage_Cost', 'Cash_Remaining'
        ])
        
        summary = {
            'Initial_Capital': self.initial_capital,
            'Ending_Capital': round(portfolio_values[-1], 2),
            'Total_Trades': len(trade_df),
            'Total_Commission_Paid': round(tot_fee, 2),
            'Total_Slippage_Cost': round(tot_slip, 2),
            'Total_Friction': round(tot_fee + tot_slip, 2),
            'Commission_Pct': self.commission_pct,
            'Slippage_Pct': self.slippage_pct
        }
        
        return equity_df, trade_df, summary
