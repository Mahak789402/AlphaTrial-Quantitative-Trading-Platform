"""
AlphaTrial Validation Engine (Simplified)
- In-Sample (70%) vs Out-of-Sample (30%) Overfitting Check
- Walk-Forward Rolling-Window Analysis
- Market Regime Breakdown (Bull, Bear, Chop)
- Brownie Point: Transaction Fee Sensitivity Shock
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from strategies.base_strategy import BaseStrategy
from .simulator import BacktestSimulator
from .metrics import compute_performance_metrics

def split_in_out_of_sample(df: pd.DataFrame, train_ratio: float = 0.70) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Chronological 70/30 split without shuffling."""
    cut = int(len(df) * train_ratio)
    return df.iloc[:cut].copy(), df.iloc[cut:].copy()

def evaluate_train_test_robustness(
    strategy: BaseStrategy,
    df: pd.DataFrame,
    train_ratio: float = 0.70,
    initial_capital: float = 100_000.0,
    commission_pct: float = 0.0010,
    slippage_pct: float = 0.0005
) -> Dict[str, Any]:
    """Train aur Test data par performance compare karke degradation index nikalta hai."""
    df_train, df_test = split_in_out_of_sample(df, train_ratio)
    sim = BacktestSimulator(initial_capital, commission_pct, slippage_pct)
    
    # Train test run
    eq_train, tr_train, _ = sim.run_backtest(df_train, strategy.generate_signals(df_train))
    m_train = compute_performance_metrics(eq_train['Portfolio_Value'], tr_train)
    
    eq_test, tr_test, _ = sim.run_backtest(df_test, strategy.generate_signals(df_test))
    m_test = compute_performance_metrics(eq_test['Portfolio_Value'], tr_test)
    
    s_tr, s_te = m_train['Sharpe Ratio'], m_test['Sharpe Ratio']
    deg = round(((s_tr - s_te) / s_tr) * 100.0, 2) if s_tr > 0 else 0.0
    
    is_overfit = deg > 50.0 or (s_tr > 0.5 and s_te < 0)
    verdict = "OVERFITTING ALERT" if is_overfit else "EXCELLENT GENERALIZATION"
    detail = f"Sharpe degraded by {deg}% on unseen data." if is_overfit else "Performance generalized well."
    
    return {
        "Train_Metrics": m_train, "Test_Metrics": m_test,
        "Train_Split_Date": str(df_train.index[-1].date()),
        "Test_Start_Date": str(df_test.index[0].date()),
        "Sharpe_Degradation_Pct": deg,
        "Is_Overfitted": is_overfit, "Verdict": verdict, "Verdict_Detail": detail,
        "Train_Equity": eq_train, "Test_Equity": eq_test
    }

def run_walk_forward_analysis(
    strategy_class,
    strategy_params: Dict[str, Any],
    df: pd.DataFrame,
    train_window: int = 250,
    test_window: int = 60,
    initial_capital: float = 100_000.0,
    commission_pct: float = 0.0010,
    slippage_pct: float = 0.0005
) -> pd.DataFrame:
    """Rolling windows par out-of-sample forward slices test karta hai."""
    sim = BacktestSimulator(initial_capital, commission_pct, slippage_pct)
    res = []
    idx = 0
    w_id = 1
    
    while idx + train_window + test_window <= len(df):
        slice_test = df.iloc[idx + train_window : idx + train_window + test_window]
        strat = strategy_class(**strategy_params)
        eq, tr, _ = sim.run_backtest(slice_test, strat.generate_signals(slice_test))
        m = compute_performance_metrics(eq['Portfolio_Value'], tr)
        
        bnh_ret = round(((eq['Benchmark_Value'].iloc[-1] - eq['Benchmark_Value'].iloc[0]) / eq['Benchmark_Value'].iloc[0]) * 100.0, 2)
        res.append({
            "Window": f"W{w_id}",
            "Test_Start": str(slice_test.index[0].date()),
            "Test_End": str(slice_test.index[-1].date()),
            "OOS_Return (%)": m['Total Return (%)'],
            "Benchmark_Return (%)": bnh_ret,
            "OOS_Sharpe": m['Sharpe Ratio'],
            "OOS_MaxDD (%)": m['Max Drawdown (%)'],
            "Trades": m['Completed Round Trips']
        })
        idx += test_window
        w_id += 1
        
    return pd.DataFrame(res)

def decompose_market_regimes(df: pd.DataFrame, equity_df: pd.DataFrame) -> pd.DataFrame:
    """Performance ko Bull, Bear, aur Chop regimes mein split karta hai."""
    close = df['Close']
    sma200 = close.rolling(200).mean().bfill()
    ret20 = close.pct_change(20).bfill()
    
    regimes = []
    for c, m, r in zip(close, sma200, ret20):
        if c > m and r > 0.01: regimes.append("Bull Trend")
        elif c < m and r < -0.01: regimes.append("Bear Trend")
        else: regimes.append("Sideways / Chop")
        
    reg_series = pd.Series(regimes, index=df.index)
    strat_ret = equity_df['Daily_Return']
    bnh_ret = equity_df['Benchmark_Daily_Return']
    
    out = []
    for reg in ["Bull Trend", "Bear Trend", "Sideways / Chop"]:
        mask = (reg_series == reg)
        days = mask.sum()
        if days > 0:
            s_cum = float(np.prod(1.0 + strat_ret[mask]) - 1.0) * 100.0
            b_cum = float(np.prod(1.0 + bnh_ret[mask]) - 1.0) * 100.0
            sd = strat_ret[mask].std()
            sh = (strat_ret[mask].mean() / (sd + 1e-9)) * np.sqrt(252) if sd > 1e-6 else 0.0
            out.append({
                "Market Regime": reg, "Trading Days": int(days),
                "% of Timeline": round(float(days / len(df) * 100), 1),
                "Strategy Return (%)": round(s_cum, 2), "Benchmark Return (%)": round(b_cum, 2),
                "Regime Sharpe": round(float(sh), 2)
            })
    return pd.DataFrame(out)

def run_fee_sensitivity_analysis(
    strategy: BaseStrategy,
    df: pd.DataFrame,
    fee_levels_bps: List[int] = [0, 5, 10, 20, 35, 50],
    slippage_bps: int = 5,
    initial_capital: float = 100_000.0
) -> pd.DataFrame:
    """Friction badha kar dikhata hai ki transaction costs profit ko kaise khatam karte hain."""
    sig = strategy.generate_signals(df)
    res = []
    for bps in fee_levels_bps:
        comm = bps / 10000.0
        slip = slippage_bps / 10000.0
        sim = BacktestSimulator(initial_capital, comm, slip)
        eq, tr, s = sim.run_backtest(df, sig)
        m = compute_performance_metrics(eq['Portfolio_Value'], tr)
        res.append({
            "Commission Fee (bps)": bps,
            "Effective Fee (%)": round(comm * 100, 3),
            "Ending Capital ($)": s['Ending_Capital'],
            "Total Return (%)": m['Total Return (%)'],
            "Sharpe Ratio": m['Sharpe Ratio'],
            "Total Friction Paid ($)": s['Total_Friction']
        })
    return pd.DataFrame(res)
