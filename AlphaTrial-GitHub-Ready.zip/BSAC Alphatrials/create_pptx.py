"""
Script to generate native PowerPoint (.pptx) presentation for Team MechMinds
Using Windows PowerPoint COM automation.
"""

import os
import sys
import win32com.client

def create_presentation():
    output_path = os.path.abspath("MechMinds_AlphaTrial_Presentation.pptx")
    
    # Initialize PowerPoint
    ppt_app = win32com.client.Dispatch("PowerPoint.Application")
    # ppt_app.Visible = 1
    
    # 16:9 widescreen or default
    presentation = ppt_app.Presentations.Add()
    # 16:9 Widescreen dimensions: width = 960 points, height = 540 points
    presentation.PageSetup.SlideWidth = 960
    presentation.PageSetup.SlideHeight = 540
    
    # Colors (RGB format in integers: R + G*256 + B*65536)
    COLOR_BG = 0x190F0B       # Dark Navy (#0B0F19)
    COLOR_CARD = 0x2E1C13     # Card (#131C2E)
    COLOR_CYAN = 0xFFE500     # Cyan (#00E5FF)
    COLOR_WHITE = 0xFFFFFF    # White
    COLOR_YELLOW = 0x00D6FF   # Yellow/Gold (#FFD600)
    COLOR_GREEN = 0x76E600    # Green (#00E676)
    COLOR_MUTED = 0xAEA490    # Muted grey (#90A4AE)

    # 12 Slide Definitions
    slides_data = [
        {
            "tag": "MNNIT ALLAHABAD • BSAC CODE CONFLUX 2026",
            "title": "AlphaTrial: Quantitative Strategy Platform",
            "subtitle": "Design, Backtest & Validate Rule-Based Trading Strategies with Zero Look-Ahead Bias and Friction Modeling",
            "team_box": True,
            "bullets": [],
            "notes": "Mahak Agrawal (Lead): Welcome respected judges and BSAC team. We are Team MechMinds — Mahak Agrawal (Lead), Dipan Mandal, and Mayank Agarwal. Today we present AlphaTrial."
        },
        {
            "tag": "SECTION 1: PROBLEM UNDERSTANDING & REAL-WORLD MOTIVATION",
            "title": "Why 90% of Quantitative Retail Strategies Fail",
            "subtitle": "The critical gap between paper backtesting and live market execution",
            "bullets": [
                "The Frictionless Fantasy: Retail traders assume zero cost. In reality, brokerage fees (10 bps) and adverse slippage (5 bps) wipe out paper alpha.",
                "Look-Ahead Bias: Calculating signals at Day T Close and assuming execution at that exact same Day T Close — impossible in real markets.",
                "Data Snooping & Overfitting: Tuning parameters on past noise until returns look phenomenal, leading to catastrophic failure on unseen data.",
                "AlphaTrial Solution: Strict T+1 Open execution, realistic fee/slippage modeling, and 70/30 chronological In/Out-of-sample validation."
            ],
            "notes": "Mahak: Retail traders lose money because their testing is flawed. AlphaTrial enforces real-world friction and eliminates future data leakage."
        },
        {
            "tag": "SECTION 2: QUANTITATIVE CORRECTNESS & MATHEMATICAL FOUNDATION",
            "title": "Rigorously Formulated Financial Metrics",
            "subtitle": "Complies strictly with quantitative finance standards (252 trading days)",
            "bullets": [
                "Cumulative Return (%): (Ending Value - Initial Value) / Initial Value * 100",
                "CAGR (%): Annualized geometric growth rate over 252 annual trading days.",
                "Annualized Volatility (%): Daily return standard deviation * sqrt(252).",
                "Sharpe Ratio (Rf = 5%): Risk-adjusted excess return per unit of total volatility.",
                "Sortino Ratio: Penalizes strictly negative downside volatility without penalizing upside profit spikes.",
                "Maximum Drawdown (MDD %) & Calmar Ratio: Evaluates worst peak-to-trough pain vs. annualized growth."
            ],
            "notes": "Mayank: Every calculation is annualized over 252 trading days. We use Sortino and Calmar to measure true downside risk."
        },
        {
            "tag": "SECTION 3 & 7: DATA HYGIENE & ELIMINATION OF LOOK-AHEAD BIAS",
            "title": "Mathematical Proof of Zero Future Data Leakage",
            "subtitle": "Strict shift(1) execution mechanics guaranteeing zero information leakage",
            "bullets": [
                "Data Ingestion Pipeline: Strict ascending chronological sorting, OHLC consistency, and missing bar forward-filling.",
                "Execution Protocol: Signals computed at Day T Close are strictly shifted by 1 bar using signal.shift(1).",
                "Order Execution at Day T+1 Open: Trades execute at next morning's Open adjusted for adverse slippage.",
                "Automated Assertion Check: test_alpha.py proves with automated unit assertions that no trade occurs on the signal calculation date."
            ],
            "notes": "Mahak: Look-ahead bias is eliminated mathematically because all signals at Bar T Close are filled at Bar T+1 Open with adverse slippage."
        },
        {
            "tag": "SECTION 4: ENGINEERING & IMPLEMENTATION ARCHITECTURE",
            "title": "Clean, Modular & Production-Grade Codebase",
            "subtitle": "Fully accessible and reproducible software architecture",
            "bullets": [
                "data/data_loader.py: Standardized CSV loading, data hygiene, and 4-regime price generator.",
                "strategies/: Abstract BaseStrategy, SMA Crossover, RSI Mean-Reversion, Momentum, and Random Forest ML.",
                "core/: BacktestSimulator (cash limits, friction), metrics.py, optimizer.py (grid search), validator.py (IS/OOS, walk-forward).",
                "ui/ & Web Dashboard: Interactive Altair financial charts and Streamlit web dashboard with 6 deep-dive analysis tabs.",
                "Accessibility: Zero-UI terminal test suites (alphatrial_simple.py & test_alpha.py) for instant verification in seconds."
            ],
            "notes": "Dipan: Our codebase is clean and modular. A standalone terminal CLI verifies calculations in seconds, and our Streamlit dashboard provides deep interactive analysis."
        },
        {
            "tag": "SECTION 5: STRATEGY IMPLEMENTATION & RULE ENGINE",
            "title": "Rule-Based & Machine Learning Strategies",
            "subtitle": "Diverse algorithmic trading logic with distinct market edge",
            "bullets": [
                "1. SMA Crossover (Trend Following): 20 SMA crosses above 50 SMA -> Buy (1); crosses below -> Cash (0). Sidesteps major bear crashes.",
                "2. RSI Mean-Reversion: Buy when RSI <= 30 (Oversold); Exit when RSI >= 70 (Overbought). Captures range-bound oscillations.",
                "3. Momentum (Rate of Change): 20-day ROC > +1.0% -> Buy; ROC <= 0.0% -> Cash. Captures rapid directional breakouts.",
                "4. Random Forest ML Regime Classifier: Scikit-learn model trained on lagged returns, RSI, and volatility. Filters false whipsaws."
            ],
            "notes": "Dipan: We implemented moving average crossovers, RSI mean-reversion, momentum, and a Random Forest ML model trained strictly on past data."
        },
        {
            "tag": "SECTION 5 & 7: DEMONSTRATED RESULTS VS BENCHMARK",
            "title": "Live Results on NIFTY 50 Dataset (1,100 Trading Days)",
            "subtitle": "Comparing rule-based performance against passive Buy & Hold",
            "bullets": [
                "Ending Capital: Strategy reached INR 103,127.99 vs. INR 102,863.52 for Buy & Hold (+INR 264.47 net excess profit).",
                "Cumulative Return: Strategy delivered +3.13% vs. +2.60% for Buy & Hold (+0.53% alpha).",
                "Maximum Drawdown (Capital Preservation): Buy & Hold suffered a brutal -46.50% crash; Strategy limited drawdown to 24.72% (+21.78% risk saved!).",
                "Annualized Volatility: Strategy reduced volatility from 19.43% down to 11.66% (smoother equity curve).",
                "Win Rate & Real Costs: 57.14% win rate across 28 completed trades, beating the market even after paying INR 3,981 in real friction!"
            ],
            "notes": "Mayank: While Buy & Hold crashed by 46.50%, AlphaTrial restricted maximum drawdown to 24.72% by switching to cash, delivering positive excess alpha."
        },
        {
            "tag": "BROWNIE POINT 1: TRANSACTION FEE SENSITIVITY SHOCK",
            "title": "How Real Market Friction Destroys Paper Alpha",
            "subtitle": "Systematically scaling fees from 0 bps to 50 bps to reveal strategy viability",
            "bullets": [
                "0 bps (Frictionless Fantasy): +5.34% Return | INR 105,339 Final Capital | INR 0.00 Fee",
                "5 bps (Institutional Rate): +4.00% Return | INR 103,998 Final Capital | INR 1,340 Fee",
                "10 bps (Standard Retail): +3.13% Return | INR 103,127 Final Capital | INR 2,654 Fee",
                "20 bps (Elevated Friction): +1.13% Return | INR 101,128 Final Capital | INR 5,268 Fee",
                "35 bps (Heavy Churn): -2.81% Loss | INR 97,192 Final Capital | INR 9,143 Fee",
                "50 bps (Extreme Friction): -5.66% Loss | INR 94,339 Final Capital | INR 12,930 Fee Paid",
                "Key Insight: Unmonitored turnover extracts over INR 12,930, proving why fee sensitivity modeling is essential."
            ],
            "notes": "Dipan: For Brownie Point 1, our Fee Sensitivity Shock proves how friction erodes alpha. A strategy that appears profitable on paper loses over 12,000 at 50 bps."
        },
        {
            "tag": "BROWNIE POINT 2 & ADVANCED: OVERFITTING INSPECTOR",
            "title": "In-Sample (70%) vs Out-of-Sample (30%) Robustness",
            "subtitle": "Chronological train/test split with automated Sharpe Degradation Index",
            "bullets": [
                "Chronological Non-Overlapping Split: First 70% (770 bars) for training; final 30% (330 bars) held out as unseen test data.",
                "Sharpe Degradation Index: [(Sharpe_Train - Sharpe_Test) / Sharpe_Train] * 100",
                "Automated Overfitting Alert: Flags a high-priority warning if degradation exceeds 50% or test Sharpe collapses.",
                "Live Verification Result: In-Sample Sharpe = -0.66, Out-of-Sample Sharpe = +0.36. Sharpe Degradation = 0.0%.",
                "Validation Verdict: [EXCELLENT GENERALIZATION - ROBUST] (Avoided curve-fitting, succeeded on unseen data)."
            ],
            "notes": "Mayank: For Brownie Point 2, our Sharpe Degradation Index automatically triggers an Overfitting Alert if test performance degrades by more than 50%."
        },
        {
            "tag": "ADVANCED FUNCTIONALITY: WALK-FORWARD & REGIMES",
            "title": "Multi-Cycle Walk-Forward & Market Regimes",
            "subtitle": "Stress-testing strategy stability across changing market conditions",
            "bullets": [
                "Walk-Forward Analysis: 10 rolling forward cycles (250-day train, 60-day out-of-sample forward step).",
                "Cycle W3 & W4 Bear Protection: When benchmark crashed by -10.1% and -18.1%, Strategy sat safely in 100% Cash (0.0% loss).",
                "Market Regime Breakdown: Bull Trend (358 days): +45.2% | Bear Market (208 days): -27.4% vs. -62.2% benchmark crash | Sideways Chop (534 days): -2.15%.",
                "Core Takeaway: Capital preservation during structural market drops is the primary driver of quantitative outperformance."
            ],
            "notes": "Mayank: Our Walk-Forward rolling analysis shows that during prolonged market drawdowns in cycles W3 and W4, AlphaTrial sat safely in cash."
        },
        {
            "tag": "SECTION 8: SUBMISSION, ORIGINALITY & TRANSPARENCY MATRIX",
            "title": "100% BSAC Judging Guidelines Compliance",
            "subtitle": "Transparent feature tracking, library credits, and ethical AI disclosure",
            "bullets": [
                "Basic Functionalities: [Implemented] (CSV ingestion, technical strategies, cash constraints, metrics, benchmark).",
                "Advanced Functionalities: [Implemented] (Walk-forward analysis, parameter grid search, IS/OOS split, market regimes, ML classifier).",
                "Brownie Points: [Achieved] (Fee sensitivity shock, overfitting alert, risk-adjusted metrics, zero look-ahead bias proof).",
                "Open-Source Credits: pandas, numpy, scikit-learn, altair, streamlit.",
                "Ethical Disclosure: AI tools used for initial scaffolding; all mathematical models and code logic are 100% understood and defended by Team MechMinds."
            ],
            "notes": "Dipan: Every feature is transparently labeled as [Implemented], open-source libraries are credited, and our codebase is fully accessible."
        },
        {
            "tag": "SECTION 6 & 9: PRESENTATION VIVA DEFENSE & CONCLUSION",
            "title": "Team MechMinds Technical Viva Strategy",
            "subtitle": "Ready to defend our quantitative implementation before the BSAC judges",
            "bullets": [
                "Mahak Agrawal (Team Leader): Defends system architecture, look-ahead bias elimination proof, and mathematical formulas.",
                "Dipan Mandal: Defends transaction friction mechanics, fee sensitivity shock curve, and technical indicator implementation.",
                "Mayank Agarwal: Defends risk-adjusted metrics (Sortino, Calmar), In/Out-of-sample degradation index, and ML regime classifier.",
                "Summary: AlphaTrial proves that a mathematically sound, friction-aware, and regime-adaptive strategy consistently outperforms naive approaches.",
                "Thank You! Team MechMinds is now open for questions from the judges."
            ],
            "notes": "Mahak: In conclusion, Team MechMinds has delivered a mathematically sound, bias-free, and defense-ready platform. Thank you, and we welcome your questions!"
        }
    ]

    for slide_data in slides_data:
        # Add a blank slide
        slide = presentation.Slides.Add(presentation.Slides.Count + 1, 12) # 12 = ppLayoutBlank
        
        # Set Dark Background
        bg = slide.Background
        bg.Fill.Solid()
        bg.Fill.ForeColor.RGB = COLOR_BG
        
        # Top Header Tag
        tag_box = slide.Shapes.AddTextbox(1, 50, 25, 860, 25)
        tf_tag = tag_box.TextFrame
        tf_tag.WordWrap = 1
        p_tag = tf_tag.TextRange
        p_tag.Text = slide_data["tag"]
        p_tag.Font.Name = "Segoe UI"
        p_tag.Font.Size = 11
        p_tag.Font.Bold = 1
        p_tag.Font.Color.RGB = COLOR_CYAN

        # Slide Title
        title_box = slide.Shapes.AddTextbox(1, 50, 48, 860, 45)
        tf_title = title_box.TextFrame
        tf_title.WordWrap = 1
        p_title = tf_title.TextRange
        p_title.Text = slide_data["title"]
        p_title.Font.Name = "Segoe UI"
        p_title.Font.Size = 22
        p_title.Font.Bold = 1
        p_title.Font.Color.RGB = COLOR_WHITE

        # Subtitle
        sub_box = slide.Shapes.AddTextbox(1, 50, 92, 860, 25)
        tf_sub = sub_box.TextFrame
        tf_sub.WordWrap = 1
        p_sub = tf_sub.TextRange
        p_sub.Text = slide_data["subtitle"]
        p_sub.Font.Name = "Segoe UI"
        p_sub.Font.Size = 13
        p_sub.Font.Color.RGB = COLOR_MUTED

        # Slide 1 special team box
        if slide_data.get("team_box"):
            team_card = slide.Shapes.AddShape(1, 50, 140, 860, 280) # 1 = msoShapeRectangle
            team_card.Fill.Solid()
            team_card.Fill.ForeColor.RGB = COLOR_CARD
            team_card.Line.ForeColor.RGB = 0x4A2E1E
            
            tc_tf = team_card.TextFrame
            tc_tf.WordWrap = 1
            tc_tf.MarginTop = 20
            tc_tf.MarginLeft = 30
            
            tc_text = tc_tf.TextRange
            tc_text.Text = (
                "TEAM NAME: MECHMINDS\n\n"
                "• Mahak Agrawal (Team Leader) — Quantitative Architecture & Execution Engine\n"
                "• Dipan Mandal (Team Member) — Transaction Friction & Strategy Rules\n"
                "• Mayank Agarwal (Team Member) — Risk-Adjusted Ratios & Overfit Validator\n\n"
                "PLATFORM STATUS:\n"
                "✓ Basic Functionalities: [Implemented]   ✓ Advanced Quant: [Implemented]   ✓ Brownie Points: [Achieved]"
            )
            tc_text.Font.Name = "Segoe UI"
            tc_text.Font.Size = 15
            tc_text.Font.Color.RGB = COLOR_WHITE
            
        else:
            # Main Content Card
            content_card = slide.Shapes.AddShape(1, 50, 130, 860, 360)
            content_card.Fill.Solid()
            content_card.Fill.ForeColor.RGB = COLOR_CARD
            content_card.Line.ForeColor.RGB = 0x4A2E1E
            
            c_tf = content_card.TextFrame
            c_tf.WordWrap = 1
            c_tf.MarginTop = 20
            c_tf.MarginLeft = 30
            c_tf.MarginRight = 30
            
            bullets_text = "\n\n".join(["• " + b for b in slide_data["bullets"]])
            c_text = c_tf.TextRange
            c_text.Text = bullets_text
            c_text.Font.Name = "Segoe UI"
            c_text.Font.Size = 13
            c_text.Font.Color.RGB = 0xDCE0CF # Off white
            
        # Add Speaker Notes
        if slide_data.get("notes"):
            notes_page = slide.NotesPage
            notes_text_box = notes_page.Shapes.Placeholders(2)
            notes_text_box.TextFrame.TextRange.Text = slide_data["notes"]

    # Save presentation with format 24 (ppSaveAsOpenXMLPresentation)
    if os.path.exists(output_path):
        try:
            os.remove(output_path)
        except Exception:
            pass
    presentation.SaveAs(output_path, 24)
    presentation.Close()
    ppt_app.Quit()
    print(f"SUCCESS: PowerPoint saved to {output_path} (Size: {os.path.getsize(output_path)} bytes)")

if __name__ == "__main__":
    create_presentation()
