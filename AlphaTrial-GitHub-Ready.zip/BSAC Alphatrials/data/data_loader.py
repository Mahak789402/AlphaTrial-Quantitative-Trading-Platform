"""
AlphaTrial Data Loader (Simplified)
CSV data ingestion, cleaning, aur multi-regime sample price generation.
Complies with BSAC (MNNIT Allahabad) Data & Validation guidelines.
"""

import os
import pandas as pd
import numpy as np
from typing import Union, Any

def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Columns ko standard title-case banata hai (Date, Open, High, Low, Close, Volume)."""
    df = df.copy()
    df.columns = [str(c).strip().capitalize() for c in df.columns]
    return df

def load_stock_csv(filepath_or_buffer: Union[str, Any]) -> pd.DataFrame:
    """
    Historical CSV file ko load aur clean karta hai:
    - Date column ko datetime index banata hai
    - Chronological ascending order mein sort karta hai
    - Missing values ko forward fill karta hai
    """
    df = pd.read_csv(filepath_or_buffer)
    df = standardize_columns(df)
    
    if 'Date' not in df.columns:
        raise ValueError("Dataset Error: 'Date' column is missing.")
        
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df = df.dropna(subset=['Date']).sort_values('Date').reset_index(drop=True)
    df.set_index('Date', inplace=True)
    
    # Required OHLCV columns check
    for col in ['Open', 'High', 'Low', 'Close']:
        if col not in df.columns:
            if 'Close' in df.columns:
                df[col] = df['Close']
            else:
                raise ValueError(f"Mandatory column '{col}' is missing.")
                
    if 'Volume' not in df.columns:
        df['Volume'] = 1_000_000
        
    for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
        
    # Clean zero & negative prices
    df['Close'] = df['Close'].replace(0, np.nan).ffill().bfill()
    df['Open'] = df['Open'].replace(0, np.nan).ffill().bfill()
    df['High'] = np.maximum(df['High'], np.maximum(df['Open'], df['Close']))
    df['Low'] = np.minimum(df['Low'], np.minimum(df['Open'], df['Close']))
    
    return df

def generate_multi_regime_data(
    symbol: str = "SYNTH_TRIAL",
    start_date: str = "2021-01-01",
    num_days: int = 1000,
    initial_price: float = 150.0,
    seed: int = 42
) -> pd.DataFrame:
    """
    Stress-testing ke liye 4 market regimes create karta hai:
    1. Bull Market (Days 0-350)
    2. Bear / Crash Market (Days 350-500)
    3. Sideways Chop (Days 500-750)
    4. Recovery (Days 750-1000)
    """
    np.random.seed(seed)
    dates = pd.date_range(start=start_date, periods=num_days, freq='B')
    
    returns = np.zeros(num_days)
    returns[0:350] = np.random.normal(0.0007, 0.009, 350)       # Bull: +18% drift
    returns[350:500] = np.random.normal(-0.0030, 0.022, 150)    # Crash: -45% drawdown
    returns[500:750] = np.random.normal(0.0001, 0.008, 250)     # Chop: flat drift
    returns[750:num_days] = np.random.normal(0.0005, 0.010, num_days - 750) # Recovery
    
    prices = initial_price * np.exp(np.cumsum(returns))
    highs = prices * (1.0 + np.abs(np.random.normal(0.004, 0.003, num_days)))
    lows = prices * (1.0 - np.abs(np.random.normal(0.004, 0.003, num_days)))
    opens = lows + (highs - lows) * np.random.uniform(0.2, 0.8, num_days)
    volume = np.random.lognormal(mean=14.5, sigma=0.4, size=num_days).astype(int)
    
    df = pd.DataFrame({
        'Date': dates,
        'Open': np.round(opens, 2),
        'High': np.round(highs, 2),
        'Low': np.round(lows, 2),
        'Close': np.round(prices, 2),
        'Volume': volume
    }).set_index('Date')
    
    return df

def save_sample_datasets(base_dir: str):
    """Instant testing ke liye standard CSV files save karta hai."""
    sample_dir = os.path.join(base_dir, "data", "sample_data")
    os.makedirs(sample_dir, exist_ok=True)
    
    configs = [
        ("NIFTY_50_INDEX", "2020-01-01", 1100, 12000.0, 101),
        ("RELIANCE_EQ", "2020-01-01", 1100, 1500.0, 202),
        ("AAPL_TECH", "2020-01-01", 1100, 100.0, 303)
    ]
    for sym, start, days, p, s in configs:
        fp = os.path.join(sample_dir, f"{sym}.csv")
        if not os.path.exists(fp):
            df = generate_multi_regime_data(sym, start, days, p, s)
            df.to_csv(fp)
