"""
Machine Learning Regime Classifier Strategy (Simplified)
Random Forest Classifier to predict upward price direction using lagged technical features.
Complies with BSAC Look-Ahead Bias & Anti-Overfitting standards.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from typing import Dict
from .base_strategy import BaseStrategy
from .rsi_strategy import calculate_rsi

class MLRegimeStrategy(BaseStrategy):
    def __init__(
        self,
        n_estimators: int = 40,
        max_depth: int = 3,
        confidence_threshold: float = 0.52,
        train_split_ratio: float = 0.70,
        random_state: int = 42
    ):
        super().__init__(f"ML_Regime_RF_{int(confidence_threshold*100)}pct", {
            "n_estimators": n_estimators, "max_depth": max_depth, "confidence_threshold": confidence_threshold
        })
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.conf_thr = confidence_threshold
        self.train_split = train_split_ratio
        self.random_state = random_state
        self.model = None
        self.feature_names = []

    def compute_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Sirf backward-looking lagged features banata hai (no future leak)."""
        close = df['Close']
        ret1 = close.pct_change(1)
        ret5 = close.pct_change(5)
        ret20 = close.pct_change(20)
        rsi14 = calculate_rsi(close, 14) / 100.0
        vol20 = ret1.rolling(20).std()
        
        return pd.DataFrame({
            'ret1': ret1, 'ret5': ret5, 'ret20': ret20, 'rsi14': rsi14, 'vol20': vol20
        }, index=df.index)

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        X = self.compute_features(df)
        # Target: Forward 3-day return > 0 (Buy target)
        y = ((df['Close'].shift(-3) - df['Close']) > 0).astype(int)
        
        clean_idx = X.dropna().index[:-3]
        X_clean = X.loc[clean_idx]
        y_clean = y.loc[clean_idx]
        
        # 70% In-sample data par train karna
        split_idx = int(len(X_clean) * self.train_split)
        X_train, y_train = X_clean.iloc[:split_idx], y_clean.iloc[:split_idx]
        
        self.model = RandomForestClassifier(
            n_estimators=self.n_estimators, max_depth=self.max_depth, random_state=self.random_state
        )
        self.model.fit(X_train, y_train)
        self.feature_names = list(X.columns)
        
        # Probability predict karo
        probs = self.model.predict_proba(X.fillna(0))[:, 1]
        signals = pd.Series(0, index=df.index, dtype=int)
        signals[probs >= self.conf_thr] = 1
        signals.iloc[:25] = 0
        return signals

    def get_feature_importances(self) -> Dict[str, float]:
        if self.model is None or not hasattr(self.model, 'feature_importances_'):
            return {}
        return dict(zip(self.feature_names, [round(float(v), 4) for v in self.model.feature_importances_]))
