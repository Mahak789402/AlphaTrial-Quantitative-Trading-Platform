"""
Momentum / Rate of Change (ROC) Strategy (Simplified)
- ROC > threshold: Buy (1)
- ROC <= 0: Sell to Cash (0)
"""

import pandas as pd
from .base_strategy import BaseStrategy

class MomentumStrategy(BaseStrategy):
    def __init__(self, lookback: int = 20, entry_threshold: float = 1.0, exit_threshold: float = 0.0):
        super().__init__(f"Momentum_{lookback}_thr{entry_threshold}", {
            "lookback": int(lookback), "entry_threshold": float(entry_threshold), "exit_threshold": float(exit_threshold)
        })
        self.lookback = int(lookback)
        self.entry_thr = float(entry_threshold)
        self.exit_thr = float(exit_threshold)

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close = df['Close']
        # N-day percentage price change
        roc = (close - close.shift(self.lookback)) / close.shift(self.lookback) * 100.0
        
        signals = pd.Series(0, index=df.index, dtype=int)
        signals[roc > self.entry_thr] = 1
        signals.iloc[:self.lookback + 1] = 0
        return signals
