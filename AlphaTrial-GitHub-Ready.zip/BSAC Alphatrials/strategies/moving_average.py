"""
Moving Average Crossover Strategy (Simplified)
- Golden Cross (Fast > Slow): Buy (1)
- Death Cross (Fast < Slow): Sell to Cash (0)
"""

import pandas as pd
from .base_strategy import BaseStrategy

class MovingAverageCrossover(BaseStrategy):
    def __init__(self, fast_window: int = 20, slow_window: int = 50, ma_type: str = "SMA"):
        super().__init__(f"{ma_type}_Cross_{fast_window}_{slow_window}", {
            "fast_window": int(fast_window),
            "slow_window": int(slow_window),
            "ma_type": ma_type.upper()
        })
        self.fast = int(fast_window)
        self.slow = int(slow_window)
        self.ma_type = ma_type.upper()

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close = df['Close']
        
        # Fast aur Slow Moving Average nikalna
        if self.ma_type == "EMA":
            fast_ma = close.ewm(span=self.fast, adjust=False).mean()
            slow_ma = close.ewm(span=self.slow, adjust=False).mean()
        else:
            fast_ma = close.rolling(self.fast).mean()
            slow_ma = close.rolling(self.slow).mean()

        # Signal: Fast > Slow par 1 (Buy), warna 0 (Cash)
        signals = pd.Series(0, index=df.index, dtype=int)
        signals[fast_ma > slow_ma] = 1
        signals.iloc[:self.slow] = 0  # Warm-up period 0 rakho
        return signals
