"""
RSI Mean-Reversion Strategy (Simplified)
- RSI <= 30 (Oversold): Buy (1)
- RSI >= 70 (Overbought): Sell to Cash (0)
"""

import pandas as pd
import numpy as np
from .base_strategy import BaseStrategy

def calculate_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Standard RSI calculation."""
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(period).mean()
    loss = (-delta.clip(upper=0)).rolling(period).mean()
    rs = gain / (loss + 1e-9)
    return 100.0 - (100.0 / (1.0 + rs))

class RSIStrategy(BaseStrategy):
    def __init__(self, period: int = 14, oversold: float = 30.0, overbought: float = 70.0):
        super().__init__(f"RSI_{period}_{int(oversold)}_{int(overbought)}", {
            "period": int(period), "oversold": float(oversold), "overbought": float(overbought)
        })
        self.period = int(period)
        self.oversold = float(oversold)
        self.overbought = float(overbought)

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        rsi = calculate_rsi(df['Close'], self.period)
        
        # State machine: Position tab tak hold rehti hai jab tak opposite condition trigger na ho
        positions = []
        state = 0
        for val in rsi:
            if np.isnan(val):
                positions.append(0)
                continue
            if val <= self.oversold:
                state = 1
            elif val >= self.overbought:
                state = 0
            positions.append(state)
            
        signals = pd.Series(positions, index=df.index, dtype=int)
        signals.iloc[:self.period + 1] = 0
        return signals
