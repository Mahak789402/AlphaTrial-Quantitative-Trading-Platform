"""
AlphaTrial Financial Visualizations Engine
Builds interactive, high-fidelity Altair and Streamlit charts for quant analytics.
"""

import pandas as pd
import numpy as np
import altair as alt
from typing import Dict, Any

def create_equity_chart(equity_df: pd.DataFrame) -> alt.Chart:
    """
    Renders Strategy Equity Curve vs Buy & Hold Benchmark Curve.
    """
    df = equity_df.reset_index()
    # Ensure Date column name
    if 'Date' not in df.columns and 'index' in df.columns:
        df.rename(columns={'index': 'Date'}, inplace=True)
    df['Date'] = pd.to_datetime(df['Date'])
    
    # Normalize curves to base 100 for intuitive percentage comparison
    init_strat = df['Portfolio_Value'].iloc[0]
    init_bnh = df['Benchmark_Value'].iloc[0]
    
    df['Strategy ($100 Base)'] = (df['Portfolio_Value'] / init_strat) * 100.0
    df['Benchmark ($100 Base)'] = (df['Benchmark_Value'] / init_bnh) * 100.0
    
    melted = df.melt(
        id_vars=['Date'],
        value_vars=['Strategy ($100 Base)', 'Benchmark ($100 Base)'],
        var_name='Asset',
        value_name='Normalized Equity'
    )
    
    chart = alt.Chart(melted).mark_line(strokeWidth=2.2).encode(
        x=alt.X('Date:T', title='Date', axis=alt.Axis(format='%b %Y', grid=False)),
        y=alt.Y('Normalized Equity:Q', title='Portfolio Value (Rebased to 100)', scale=alt.Scale(zero=False)),
        color=alt.Color('Asset:N', scale=alt.Scale(
            domain=['Strategy ($100 Base)', 'Benchmark ($100 Base)'],
            range=['#00E5FF', '#FF9100']
        ), legend=alt.Legend(title="", orient='top-left')),
        tooltip=[
            alt.Tooltip('Date:T', title='Date', format='%Y-%m-%d'),
            alt.Tooltip('Asset:N', title='Portfolio'),
            alt.Tooltip('Normalized Equity:Q', title='Value ($)', format='.2f')
        ]
    ).properties(
        title="Equity Growth: Strategy vs. Buy & Hold Benchmark",
        height=380
    ).interactive()
    
    return chart

def create_drawdown_chart(equity_df: pd.DataFrame) -> alt.Chart:
    """
    Renders Underwater Drawdown Chart (% peak-to-trough decline).
    """
    df = equity_df.reset_index()
    if 'Date' not in df.columns and 'index' in df.columns:
        df.rename(columns={'index': 'Date'}, inplace=True)
    df['Date'] = pd.to_datetime(df['Date'])
    df['Strategy Drawdown (%)'] = df['Drawdown'] * 100.0
    df['Benchmark Drawdown (%)'] = df['Benchmark_Drawdown'] * 100.0
    
    melted = df.melt(
        id_vars=['Date'],
        value_vars=['Strategy Drawdown (%)', 'Benchmark Drawdown (%)'],
        var_name='Portfolio',
        value_name='Drawdown (%)'
    )
    
    area_chart = alt.Chart(melted).mark_area(opacity=0.35).encode(
        x=alt.X('Date:T', title='Date', axis=alt.Axis(format='%b %Y', grid=False)),
        y=alt.Y('Drawdown (%):Q', title='Drawdown (%)', scale=alt.Scale(domain=[min(melted['Drawdown (%)'].min() * 1.05, -5.0), 0.0])),
        color=alt.Color('Portfolio:N', scale=alt.Scale(
            domain=['Strategy Drawdown (%)', 'Benchmark Drawdown (%)'],
            range=['#FF5252', '#FFA726']
        ), legend=alt.Legend(title="", orient='bottom-left')),
        tooltip=[
            alt.Tooltip('Date:T', title='Date', format='%Y-%m-%d'),
            alt.Tooltip('Portfolio:N'),
            alt.Tooltip('Drawdown (%):Q', title='Drawdown (%)', format='.2f')
        ]
    ).properties(
        title="Underwater Drawdown Profile (Risk Exposure)",
        height=220
    ).interactive()
    
    return area_chart

def create_fee_shock_chart(fee_df: pd.DataFrame) -> alt.Chart:
    """
    Visualizes Return erosion and Sharpe decline across rising fee levels.
    """
    base = alt.Chart(fee_df).encode(x=alt.X('Commission Fee (bps):O', title='Friction Fee (Basis Points)'))
    
    bar = base.mark_bar(color='#29B6F6', opacity=0.85, width=35).encode(
        y=alt.Y('Total Return (%):Q', title='Cumulative Return (%)'),
        tooltip=['Commission Fee (bps)', 'Total Return (%)', 'Total Friction Paid ($)']
    )
    
    line = base.mark_line(color='#FFD600', strokeWidth=3, point=True).encode(
        y=alt.Y('Sharpe Ratio:Q', title='Sharpe Ratio', scale=alt.Scale(zero=False)),
        tooltip=['Commission Fee (bps)', 'Sharpe Ratio']
    )
    
    chart = alt.layer(bar, line).resolve_scale(
        y='independent'
    ).properties(
        title="Fee Sensitivity Shock: Return & Sharpe Erosion Under Transaction Costs",
        height=320
    )
    return chart

def create_walk_forward_chart(wf_df: pd.DataFrame) -> alt.Chart:
    """
    Visualizes Rolling Out-Of-Sample Returns vs Benchmark.
    """
    melted = wf_df.melt(
        id_vars=['Window', 'Test_Start'],
        value_vars=['OOS_Return (%)', 'Benchmark_Return (%)'],
        var_name='Strategy',
        value_name='Return (%)'
    )
    
    chart = alt.Chart(melted).mark_bar().encode(
        x=alt.X('Window:N', title='Walk-Forward Cycle', axis=alt.Axis(labelAngle=0)),
        y=alt.Y('Return (%):Q', title='Period Return (%)'),
        color=alt.Color('Strategy:N', scale=alt.Scale(
            domain=['OOS_Return (%)', 'Benchmark_Return (%)'],
            range=['#00E676', '#FF9100']
        )),
        xOffset='Strategy:N',
        tooltip=['Window', 'Test_Start', 'Strategy', 'Return (%)']
    ).properties(
        title="Walk-Forward Out-Of-Sample Returns per Rolling Cycle",
        height=280
    )
    return chart
