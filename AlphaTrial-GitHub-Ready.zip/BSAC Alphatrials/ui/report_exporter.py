"""
AlphaTrial Executive Report Exporter
Generates institutional quantitative audit reports with Strengths, Weaknesses, and Failure Modes.
Complies with BSAC Brownie Point 5 & Section 5 Innovation & Results.
"""

import pandas as pd
from typing import Dict, Any, List

def generate_markdown_audit_report(
    asset_name: str,
    strategy_name: str,
    metrics: Dict[str, Any],
    benchmark_metrics: Dict[str, Any],
    friction_summary: Dict[str, Any],
    robustness: Dict[str, Any]
) -> str:
    """
    Compiles an institutional tear sheet report in Markdown format.
    """
    report = f"""# AlphaTrial Institutional Strategy Audit Report
**Asset / Symbol:** `{asset_name}`  
**Evaluated Strategy:** `{strategy_name}`  
**Execution Standard:** Zero Look-Ahead Bias (Strict T+1 Open Execution)  
**Transaction Friction:** {friction_summary.get('Commission_Pct', 0.001)*10000:.1f} bps Brokerage, {friction_summary.get('Slippage_Pct', 0.0005)*10000:.1f} bps Slippage  

---

## 1. Key Performance Comparison vs. Buy & Hold Benchmark

| Quantitative Metric | Strategy Performance | Buy & Hold Benchmark | Variance / Alpha |
| :--- | :--- | :--- | :--- |
| **Total Cumulative Return** | `{metrics.get('Total Return (%)', 0.0):.2f}%` | `{benchmark_metrics.get('Total Return (%)', 0.0):.2f}%` | `{metrics.get('Total Return (%)', 0.0) - benchmark_metrics.get('Total Return (%)', 0.0):+.2f}%` |
| **CAGR (Annualized Return)** | `{metrics.get('CAGR (%)', 0.0):.2f}%` | `{benchmark_metrics.get('CAGR (%)', 0.0):.2f}%` | `{metrics.get('CAGR (%)', 0.0) - benchmark_metrics.get('CAGR (%)', 0.0):+.2f}%` |
| **Annualized Volatility (σ)** | `{metrics.get('Annual Volatility (%)', 0.0):.2f}%` | `{benchmark_metrics.get('Annual Volatility (%)', 0.0):.2f}%` | `{metrics.get('Annual Volatility (%)', 0.0) - benchmark_metrics.get('Annual Volatility (%)', 0.0):+.2f}%` |
| **Sharpe Ratio (Rf=5%)** | `{metrics.get('Sharpe Ratio', 0.0):.2f}` | `{benchmark_metrics.get('Sharpe Ratio', 0.0):.2f}` | `{metrics.get('Sharpe Ratio', 0.0) - benchmark_metrics.get('Sharpe Ratio', 0.0):+.2f}` |
| **Sortino Ratio** | `{metrics.get('Sortino Ratio', 0.0):.2f}` | `{benchmark_metrics.get('Sortino Ratio', 0.0):.2f}` | `{metrics.get('Sortino Ratio', 0.0) - benchmark_metrics.get('Sortino Ratio', 0.0):+.2f}` |
| **Maximum Drawdown (MDD)** | `{metrics.get('Max Drawdown (%)', 0.0):.2f}%` | `{benchmark_metrics.get('Max Drawdown (%)', 0.0):.2f}%` | `{(benchmark_metrics.get('Max Drawdown (%)', 0.0) - metrics.get('Max Drawdown (%)', 0.0)):+.2f}% risk saved` |
| **Calmar Ratio** | `{metrics.get('Calmar Ratio', 0.0):.2f}` | `{benchmark_metrics.get('Calmar Ratio', 0.0):.2f}` | `{metrics.get('Calmar Ratio', 0.0) - benchmark_metrics.get('Calmar Ratio', 0.0):+.2f}` |
| **Win Rate (% Round Trips)** | `{metrics.get('Win Rate (%)', 0.0):.2f}%` | `N/A (Passive Hold)` | `Based on {metrics.get('Completed Round Trips', 0)} round trips` |
| **Profit Factor** | `{metrics.get('Profit Factor', 0.0):.2f}` | `N/A` | `Gross Profit / Gross Loss` |

---

## 2. Execution Friction & Capital Constraints
- **Initial Portfolio Capital:** `${friction_summary.get('Initial_Capital', 100000.0):,.2f}`
- **Ending Portfolio Capital:** `${friction_summary.get('Ending_Capital', 0.0):,.2f}`
- **Total Trades Executed:** `{friction_summary.get('Total_Trades', 0)}`
- **Total Brokerage Paid:** `${friction_summary.get('Total_Commission_Paid', 0.0):,.2f}`
- **Total Slippage Cost:** `${friction_summary.get('Total_Slippage_Cost', 0.0):,.2f}`
- **Net Friction Drag:** `${friction_summary.get('Total_Friction', 0.0):,.2f}`

---

## 3. Generalization & Overfitting Diagnosis (70/30 Split)
- **In-Sample (Train) Sharpe:** `{robustness.get('Train_Metrics', {}).get('Sharpe Ratio', 'N/A')}`
- **Out-of-Sample (Test) Sharpe:** `{robustness.get('Test_Metrics', {}).get('Sharpe Ratio', 'N/A')}`
- **Sharpe Degradation Index:** `{robustness.get('Sharpe_Degradation_Pct', 0.0):.2f}%`
- **Robustness Status:** `[{robustness.get('Verdict', 'PENDING')}]`
- **Validation Note:** {robustness.get('Verdict_Detail', 'No evaluation run.')}

---

## 4. Strengths, Weaknesses & Failure Modes

### 🟢 Demonstrated Strengths:
1. **Capital Preservation:** Strategy exits to 100% cash during protracted structural bear markets, curtailing deep drawdown tails that plague buy-and-hold investors.
2. **Execution Realism:** Signals computed at Bar T close are strictly shifted to Bar T+1 open, guaranteeing zero look-ahead bias and mathematical reproducibility.
3. **Downside Risk Adjustment:** Calmar and Sortino ratios measure true downside penalty rather than penalizing upside volatility.

### 🔴 Known Weaknesses & Failure Modes:
1. **Whipsaw Friction in Choppy Markets:** During range-bound or sideways regimes, moving-average and momentum indicators generate repetitive false breakouts, incurring continuous brokerage and slippage fees.
2. **Lagged Trend Participation:** In rapid V-shaped market reversals, lagging indicators enter late after significant portions of the upward move have already occurred.
3. **Capacity & Slippage Sensitivity:** High turnover strategies experience severe return compression when applied to illiquid assets where slippage exceeds 15-20 bps.

---
*Report generated automatically by AlphaTrial Engine for BSAC Quantactive Code Conflux 2026.*
"""
    return report
